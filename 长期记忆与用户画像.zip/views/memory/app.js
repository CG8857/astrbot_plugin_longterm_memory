const PLUGIN = "astrbot_plugin_longterm_memory";

const SETTINGS_GROUPS = [
  {
    title: "基础设置",
    note: "记录范围与图片识别",
    fields: [
      { key: "enabled", label: "启用长期记忆", type: "bool", hint: "关闭后不再记录、检索和注入记忆。" },
      { key: "capture_group_all", label: "记录群聊所有消息", type: "bool", hint: "默认只记录与机器人对话的群消息。" },
      { key: "enable_image_understanding", label: "识别图片内容", type: "bool", hint: "需要多模态模型支持图片输入。" },
      { key: "max_images_per_message", label: "每条消息图片数", type: "number", min: 0, max: 4, step: 1 },
      { key: "ignore_commands", label: "忽略 / 指令", type: "bool", hint: "避免把管理指令写入记忆。" },
    ],
  },
  {
    title: "记忆抽取与整理",
    note: "自动抽取与每日任务",
    fields: [
      { key: "enable_auto_extract", label: "自动抽取记忆", type: "bool" },
      { key: "extract_every_n_messages", label: "每 N 条消息抽取", type: "number", min: 1, max: 100, step: 1 },
      { key: "consolidation_time", label: "每日整理时间", type: "time", hint: "24 小时制，修改后无需重启。" },
      { key: "catch_up_on_start", label: "启动时补整理", type: "bool" },
      { key: "profile_min_messages", label: "画像最少消息数", type: "number", min: 1, max: 1000, step: 1 },
      { key: "profile_refresh_days", label: "画像刷新间隔（天）", type: "number", min: 1, max: 365, step: 1 },
      { key: "retention_days", label: "数据保留天数", type: "number", min: 0, max: 3650, step: 1, hint: "0 表示永久保留。" },
    ],
  },
  {
    title: "提示词注入",
    note: "控制注入方式与长度",
    fields: [
      {
        key: "inject_mode",
        label: "注入方式",
        type: "select",
        options: [
          ["extra_user_part", "附加用户内容（推荐）"],
          ["system_prompt", "追加系统提示词"],
          ["off", "关闭注入"],
        ],
      },
      { key: "max_inject_memories", label: "最多注入记忆数", type: "number", min: 1, max: 20, step: 1 },
      { key: "max_inject_chars", label: "注入内容字符上限", type: "number", min: 200, max: 8000, step: 100 },
      { key: "max_profile_chars", label: "画像字符上限", type: "number", min: 200, max: 4000, step: 100 },
    ],
  },
  {
    title: "高级设置",
    note: "模型与工具",
    fields: [
      { key: "llm_provider_id", label: "记忆整理模型", type: "provider", hint: "留空则使用当前会话模型。" },
      { key: "vision_provider_id", label: "图片识别模型", type: "provider", hint: "留空则复用记忆整理模型。" },
      { key: "enable_llm_tools", label: "暴露记忆工具", type: "bool", hint: "修改后需重载插件。" },
      { key: "debug", label: "调试日志", type: "bool" },
    ],
  },
];

const state = {
  bridge: null,
  tab: "overview",
  loaded: { overview: false, users: false, memories: false, settings: false },
  userOffset: 0,
  userTotal: 0,
  userSearch: "",
  userMore: false,
  memoryOffset: 0,
  memoryTotal: 0,
  memorySearch: "",
  memoryKeyword: "",
  pendingOpenUser: "",
  providers: [],
};

const $ = (sel) => document.querySelector(sel);

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function formatDate(value) {
  if (!value) return "—";
  return String(value).replace("T", " ").slice(0, 16);
}

function localDateString(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function toast(message, isError = false) {
  const el = $("#toast");
  el.textContent = message;
  el.className = `toast show${isError ? " error" : ""}`;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => {
    el.className = "toast";
  }, 2600);
}

function applyTheme(context) {
  if (!context) return;
  const primary = context.themeColors?.primary;
  const secondary = context.themeColors?.secondary;
  if (primary) document.documentElement.style.setProperty("--primary", primary);
  if (secondary) document.documentElement.style.setProperty("--primary-strong", secondary);
}

async function initBridge() {
  const bridge = window.AstrBotPluginView || window.AstrBotPluginPage;
  if (!bridge) return;
  state.bridge = bridge;
  try {
    const context = await Promise.race([bridge.ready(), delay(1800)]);
    applyTheme(context);
    if (typeof bridge.onContext === "function") {
      bridge.onContext(applyTheme);
    }
  } catch (error) {
    console.warn("bridge ready failed", error);
  }
}

async function apiGet(endpoint, params = {}) {
  if (state.bridge?.apiGet) {
    return state.bridge.apiGet(endpoint, params);
  }
  const url = new URL(
    `/api/v1/plugins/extensions/${PLUGIN}/${endpoint}`,
    window.location.origin,
  );
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, value);
    }
  });
  const response = await fetch(url, { credentials: "same-origin" });
  if (!response.ok) throw new Error(await response.text());
  const data = await response.json();
  if (data && data.status === "error") throw new Error(data.message || "请求失败");
  if (data && data.status === "ok" && data.data !== undefined) return data.data;
  return data;
}

async function apiPost(endpoint, body = {}) {
  if (state.bridge?.apiPost) {
    return state.bridge.apiPost(endpoint, body);
  }
  const response = await fetch(
    `/api/v1/plugins/extensions/${PLUGIN}/${endpoint}`,
    {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    },
  );
  if (!response.ok) throw new Error(await response.text());
  const data = await response.json();
  if (data && data.status === "error") throw new Error(data.message || "请求失败");
  if (data && data.status === "ok" && data.data !== undefined) return data.data;
  return data;
}

function confirmDialog(title, message, confirmText = "确认删除") {
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true">
        <h3>${escapeHtml(title)}</h3>
        <p>${escapeHtml(message)}</p>
        <div class="modal-actions">
          <button class="btn ghost" data-modal="cancel" type="button">取消</button>
          <button class="btn danger" data-modal="ok" type="button">${escapeHtml(confirmText)}</button>
        </div>
      </div>`;
    document.body.appendChild(backdrop);
    const close = (result) => {
      backdrop.remove();
      resolve(result);
    };
    backdrop.addEventListener("click", (event) => {
      const button = event.target.closest("[data-modal]");
      if (button) close(button.dataset.modal === "ok");
      else if (event.target === backdrop) close(false);
    });
  });
}

/* ------------------------------------------------------------------ */
/* 概览                                                                */
/* ------------------------------------------------------------------ */
async function loadOverview() {
  try {
    const data = await apiGet("overview");
    const stats = data.stats || {};
    $("#stats").innerHTML = [
      ["用户", stats.users ?? 0, `画像 ${stats.profiles ?? 0}`],
      ["记忆", stats.memories ?? 0, `消息 ${stats.messages ?? 0}`],
      ["关键字", stats.keywords ?? 0, `待整理 ${stats.pending ?? 0}`],
      ["今日消息", stats.today_messages ?? 0, data.settings?.enabled ? "记忆已启用" : "记忆已关闭"],
    ]
      .map(
        ([label, value, sub]) => `
        <div class="stat">
          <div class="label">${escapeHtml(label)}</div>
          <div class="value">${escapeHtml(value)}</div>
          <div class="sub">${escapeHtml(sub)}</div>
        </div>`,
      )
      .join("");

    $("#pending-note").textContent = `${stats.pending ?? 0} 条消息待整理`;
    $("#last-consolidation").textContent = `上次整理：${formatDate(stats.last_consolidation)}`;

    const recent = data.recent_memories || [];
    $("#recent-memories").innerHTML = recent.length
      ? recent.map((item) => renderMemory(item, true)).join("")
      : `<div class="empty">还没有记忆，先和机器人聊几句吧。</div>`;

    const users = data.recent_users || [];
    $("#recent-users").innerHTML = users.length
      ? users.map(renderCompactUser).join("")
      : `<div class="empty">还没有用户记录。</div>`;

    state.loaded.overview = true;
  } catch (error) {
    $("#stats").innerHTML = `<div class="empty">加载失败：${escapeHtml(error.message)}</div>`;
  }
}

function renderCompactUser(user) {
  const name = user.nickname || user.qq || user.user_key;
  const initial = String(name).trim().charAt(0) || "U";
  return `
    <div class="user-head" data-action="open-user" data-key="${escapeHtml(user.user_key)}" style="cursor:pointer">
      <div class="avatar">${escapeHtml(initial)}</div>
      <div class="user-meta">
        <div class="user-name">${escapeHtml(name)}</div>
        <div class="user-sub">${escapeHtml(user.qq ? `QQ ${user.qq}` : user.platform)} · 最近 ${formatDate(user.last_seen)}</div>
      </div>
      <div class="badges">
        <span class="badge primary">${escapeHtml(user.memory_count ?? 0)} 条记忆</span>
        <span class="badge">${escapeHtml(user.message_count ?? 0)} 条消息</span>
      </div>
    </div>`;
}

/* ------------------------------------------------------------------ */
/* 用户                                                                */
/* ------------------------------------------------------------------ */
function renderUserCard(user) {
  const name = user.nickname || user.qq || user.user_key;
  const initial = String(name).trim().charAt(0) || "U";
  return `
    <details class="card user-card" data-key="${escapeHtml(user.user_key)}">
      <summary>
        <div class="user-head">
          <div class="avatar">${escapeHtml(initial)}</div>
          <div class="user-meta">
            <div class="user-name">${escapeHtml(name)}</div>
            <div class="user-sub">${escapeHtml(user.qq ? `QQ ${user.qq}` : user.platform)} · 最近 ${formatDate(user.last_seen)}</div>
          </div>
          <div class="badges">
            <span class="badge primary">${escapeHtml(user.memory_count ?? 0)} 条记忆</span>
            <span class="badge">${escapeHtml(user.message_count ?? 0)} 条消息</span>
          </div>
        </div>
      </summary>
      <div class="card-body" data-loaded="0">
        <div class="empty">展开后加载画像与记忆…</div>
      </div>
    </details>`;
}

async function loadUsers(reset = true) {
  if (reset) {
    state.userOffset = 0;
    $("#user-list").innerHTML = `<div class="empty">加载中…</div>`;
  }
  try {
    const data = await apiGet("users", {
      search: state.userSearch,
      limit: 20,
      offset: state.userOffset,
    });
    const items = data.items || [];
    state.userTotal = data.total || 0;
    if (reset) $("#user-list").innerHTML = "";
    if (!items.length && reset) {
      $("#user-list").innerHTML = `<div class="empty">没有找到用户。</div>`;
    } else {
      $("#user-list").insertAdjacentHTML(
        "beforeend",
        items.map(renderUserCard).join(""),
      );
    }
    state.userOffset += items.length;
    $("#user-more").hidden = state.userOffset >= state.userTotal;
    state.loaded.users = true;

    if (state.pendingOpenUser) {
      const target = document.querySelector(
        `.user-card[data-key="${CSS.escape(state.pendingOpenUser)}"]`,
      );
      if (target) {
        target.open = true;
        state.pendingOpenUser = "";
        target.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
  } catch (error) {
    $("#user-list").innerHTML = `<div class="empty">加载失败：${escapeHtml(error.message)}</div>`;
  }
}

async function loadUserDetail(detail, offset = 0) {
  const key = detail.dataset.key;
  const body = detail.querySelector(".card-body");
  if (!key || !body) return;
  if (offset === 0) body.innerHTML = `<div class="empty">加载中…</div>`;
  try {
    const data = await apiGet("user", { key, limit: 20, offset });
    const user = data.user || {};
    const memories = data.memories || [];
    const keywords = data.keywords || [];
    const summaries = data.summaries || [];
    const total = data.memories_total || 0;
    const profile = (user.profile || "").trim();
    const tags = user.tags || [];

    if (offset > 0) {
      const list = body.querySelector('[data-role="user-memories"]');
      if (list) {
        list.insertAdjacentHTML(
          "beforeend",
          memories.map((item) => renderMemory(item, false)).join(""),
        );
      }
      const oldMore = body.querySelector('[data-action="more-user-memories"]');
      if (oldMore) oldMore.remove();
      if (offset + memories.length < total) {
        body.insertAdjacentHTML(
          "beforeend",
          `<button class="btn ghost more" data-action="more-user-memories" data-key="${escapeHtml(key)}" data-offset="${offset + memories.length}" type="button">加载更多</button>`,
        );
      }
      return;
    }

    const profileHtml = `
      <div class="section">
        <div class="section-head">
          <span class="section-title">用户画像</span>
          <button class="btn tiny danger" data-action="delete-profile" data-key="${escapeHtml(key)}" type="button">删除画像</button>
        </div>
        <div class="profile-box ${profile ? "" : "empty-profile"}">${profile ? escapeHtml(profile) : "暂无画像，积累一些对话后会自动生成。"}</div>
        ${tags.length ? `<div class="chips" style="margin-top:8px">${tags.map((tag) => `<span class="chip">${escapeHtml(tag)}</span>`).join("")}</div>` : ""}
      </div>`;

    const summaryHtml = summaries.length
      ? `<details class="section card" style="margin-top:14px">
          <summary><span class="summary-title">每日摘要</span><span class="summary-note">${summaries.length} 天</span></summary>
          <div class="card-body list">
            ${summaries
              .map(
                (item) => `
                <div class="summary-item">
                  <div class="day">${escapeHtml(item.day)}</div>
                  <div>${escapeHtml(item.summary || "（无摘要）")}</div>
                </div>`,
              )
              .join("")}
          </div>
        </details>`
      : "";

    const keywordHtml = keywords.length
      ? `<div class="section">
          <div class="section-head"><span class="section-title">关键字</span><span class="summary-note">${keywords.length} 个</span></div>
          <div class="chips">${keywords
            .map(
              (item) => `
              <span class="chip">${escapeHtml(item.keyword)} · ${escapeHtml(item.count)}
                <button data-action="filter-keyword" data-kw="${escapeHtml(item.keyword)}" title="查看相关记忆" type="button">›</button>
              </span>`,
            )
            .join("")}</div>
        </div>`
      : "";

    const memoryHtml = `
      <div class="section">
        <div class="section-head">
          <span class="section-title">记忆 · ${total} 条</span>
          <button class="btn tiny danger" data-action="delete-user" data-key="${escapeHtml(key)}" type="button">清空用户数据</button>
        </div>
        <div class="list" data-role="user-memories">
          ${
            memories.length
              ? memories.map((item) => renderMemory(item, false)).join("")
              : `<div class="empty">这位用户还没有记忆。</div>`
          }
        </div>
        ${
          offset + memories.length < total
            ? `<button class="btn ghost more" data-action="more-user-memories" data-key="${escapeHtml(key)}" data-offset="${offset + memories.length}" type="button">加载更多</button>`
            : ""
        }
      </div>`;

    body.innerHTML = profileHtml + summaryHtml + keywordHtml + memoryHtml;
    body.dataset.loaded = "1";
  } catch (error) {
    body.innerHTML = `<div class="empty">加载失败：${escapeHtml(error.message)}</div>`;
  }
}

/* ------------------------------------------------------------------ */
/* 记忆                                                                */
/* ------------------------------------------------------------------ */
function renderMemory(memory, showUser = false) {
  const keywords = memory.keywords || [];
  const userLabel = showUser
    ? `<button class="link-btn user-link" data-action="open-user" data-key="${escapeHtml(memory.user_key)}" type="button">${escapeHtml(memory.nickname || memory.qq || memory.user_key)}</button><span class="dot"></span>`
    : "";
  return `
    <div class="memory" data-memory-id="${escapeHtml(memory.id)}">
      <div class="memory-top">
        <div class="memory-text">${escapeHtml(memory.content)}</div>
        <div class="memory-actions">
          <button class="btn tiny danger" data-action="delete-memory" data-id="${escapeHtml(memory.id)}" type="button">删除</button>
        </div>
      </div>
      ${
        keywords.length
          ? `<div class="chips" style="margin-top:8px">${keywords
              .map(
                (kw) => `
                <span class="chip">${escapeHtml(kw)}
                  <button data-action="delete-keyword" data-id="${escapeHtml(memory.id)}" data-kw="${escapeHtml(kw)}" title="删除关键字" type="button">×</button>
                </span>`,
              )
              .join("")}</div>`
          : ""
      }
      <div class="memory-meta">
        ${userLabel}
        <span>${escapeHtml(memory.category || "其他")}</span>
        <span class="dot">${escapeHtml(memory.memory_date || "")}</span>
        <span class="dot">重要度 ${escapeHtml(memory.importance ?? 3)}</span>
        <span class="dot">${escapeHtml(memory.source || "chat")}</span>
      </div>
    </div>`;
}

async function loadMemories(reset = true) {
  if (reset) {
    state.memoryOffset = 0;
    $("#memory-list").innerHTML = `<div class="empty">加载中…</div>`;
  }
  try {
    const data = await apiGet("memories", {
      q: state.memorySearch,
      keyword: state.memoryKeyword,
      limit: 20,
      offset: state.memoryOffset,
    });
    const items = data.items || [];
    state.memoryTotal = data.total || 0;
    if (reset) $("#memory-list").innerHTML = "";
    if (!items.length && reset) {
      $("#memory-list").innerHTML = `<div class="empty">没有找到记忆。</div>`;
    } else {
      $("#memory-list").insertAdjacentHTML(
        "beforeend",
        items.map((item) => renderMemory(item, true)).join(""),
      );
    }
    state.memoryOffset += items.length;
    $("#memory-more").hidden = state.memoryOffset >= state.memoryTotal;
    state.loaded.memories = true;
  } catch (error) {
    $("#memory-list").innerHTML = `<div class="empty">加载失败：${escapeHtml(error.message)}</div>`;
  }
}

function setKeywordFilter(keyword) {
  state.memoryKeyword = keyword || "";
  const row = $("#active-filter");
  const chip = $("#active-filter-chip");
  if (state.memoryKeyword) {
    row.hidden = false;
    chip.textContent = `关键字：${state.memoryKeyword}`;
  } else {
    row.hidden = true;
  }
  switchTab("memories");
  loadMemories(true);
}

/* ------------------------------------------------------------------ */
/* 设置                                                                */
/* ------------------------------------------------------------------ */
function renderSettings(data) {
  const values = data.values || {};
  state.providers = data.providers || [];
  const providerOptions = (selected) => {
    const options = [`<option value="">跟随当前会话</option>`];
    state.providers.forEach((provider) => {
      const label = `${provider.id || "未命名"}${provider.model ? ` · ${provider.model}` : ""}`;
      options.push(
        `<option value="${escapeHtml(provider.id)}" ${provider.id === selected ? "selected" : ""}>${escapeHtml(label)}</option>`,
      );
    });
    return options.join("");
  };

  $("#settings-form").innerHTML = SETTINGS_GROUPS.map(
    (group) => `
      <details class="card" open>
        <summary><span class="summary-title">${escapeHtml(group.title)}</span><span class="summary-note">${escapeHtml(group.note)}</span></summary>
        <div class="card-body">
          ${group.fields
            .map((field) => {
              const value = values[field.key];
              let control = "";
              if (field.type === "bool") {
                control = `
                  <label class="switch">
                    <input type="checkbox" data-key="${field.key}" data-type="bool" ${value ? "checked" : ""} />
                    <span></span>
                  </label>`;
              } else if (field.type === "select") {
                control = `
                  <select data-key="${field.key}" data-type="string">
                    ${field.options
                      .map(
                        ([key, label]) =>
                          `<option value="${escapeHtml(key)}" ${String(value) === key ? "selected" : ""}>${escapeHtml(label)}</option>`,
                      )
                      .join("")}
                  </select>`;
              } else if (field.type === "provider") {
                control = `<select data-key="${field.key}" data-type="string">${providerOptions(String(value || ""))}</select>`;
              } else if (field.type === "number") {
                control = `<input type="number" data-key="${field.key}" data-type="number" value="${escapeHtml(value ?? 0)}" min="${field.min ?? 0}" max="${field.max ?? 99999}" step="${field.step ?? 1}" />`;
              } else if (field.type === "time") {
                control = `<input type="time" data-key="${field.key}" data-type="string" value="${escapeHtml(value || "00:00")}" />`;
              } else {
                control = `<input type="text" data-key="${field.key}" data-type="string" value="${escapeHtml(value ?? "")}" />`;
              }
              return `
                <div class="setting">
                  <div class="setting-info">
                    <div class="setting-label">${escapeHtml(field.label)}</div>
                    ${field.hint ? `<div class="setting-hint">${escapeHtml(field.hint)}</div>` : ""}
                  </div>
                  <div class="setting-control">${control}</div>
                </div>`;
            })
            .join("")}
        </div>
      </details>`,
  ).join("");
  state.loaded.settings = true;
}

async function loadSettings() {
  try {
    const data = await apiGet("settings");
    renderSettings(data);
  } catch (error) {
    $("#settings-form").innerHTML = `<div class="empty">加载失败：${escapeHtml(error.message)}</div>`;
  }
}

async function saveSettings() {
  const button = $("#save-settings");
  const values = {};
  document.querySelectorAll("#settings-form [data-key]").forEach((element) => {
    const key = element.dataset.key;
    const type = element.dataset.type;
    if (type === "bool") values[key] = element.checked;
    else if (type === "number") values[key] = Number(element.value);
    else values[key] = element.value;
  });
  button.disabled = true;
  button.textContent = "保存中…";
  try {
    await apiPost("settings/save", { values });
    toast("设置已保存");
    await loadOverview();
  } catch (error) {
    toast(`保存失败：${error.message}`, true);
  } finally {
    button.disabled = false;
    button.textContent = "保存设置";
  }
}

/* ------------------------------------------------------------------ */
/* 交互                                                                */
/* ------------------------------------------------------------------ */
function switchTab(tab) {
  state.tab = tab;
  document.querySelectorAll(".tab").forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === tab);
  });
  document.querySelectorAll(".panel").forEach((panel) => {
    panel.classList.toggle("active", panel.id === `panel-${tab}`);
  });
  if (tab === "overview" && !state.loaded.overview) loadOverview();
  if (tab === "users" && !state.loaded.users) loadUsers(true);
  if (tab === "memories" && !state.loaded.memories) loadMemories(true);
  if (tab === "settings" && !state.loaded.settings) loadSettings();
}

function openUser(key) {
  state.pendingOpenUser = key;
  switchTab("users");
  state.userSearch = "";
  $("#user-search").value = "";
  loadUsers(true);
}

function setupEvents() {
  document.querySelectorAll(".tab").forEach((button) => {
    button.addEventListener("click", () => switchTab(button.dataset.tab));
  });

  $("#refresh-btn").addEventListener("click", () => {
    const tab = state.tab;
    state.loaded[tab] = false;
    if (tab === "overview") loadOverview();
    else if (tab === "users") loadUsers(true);
    else if (tab === "memories") loadMemories(true);
    else if (tab === "settings") loadSettings();
  });

  let userTimer = 0;
  $("#user-search").addEventListener("input", (event) => {
    clearTimeout(userTimer);
    userTimer = setTimeout(() => {
      state.userSearch = event.target.value.trim();
      loadUsers(true);
    }, 300);
  });

  let memoryTimer = 0;
  $("#memory-search").addEventListener("input", (event) => {
    clearTimeout(memoryTimer);
    memoryTimer = setTimeout(() => {
      state.memorySearch = event.target.value.trim();
      loadMemories(true);
    }, 300);
  });

  $("#user-more").addEventListener("click", () => loadUsers(false));
  $("#memory-more").addEventListener("click", () => loadMemories(false));
  $("#clear-filter").addEventListener("click", () => setKeywordFilter(""));
  $("#save-settings").addEventListener("click", saveSettings);

  $("#consolidate-btn").addEventListener("click", async () => {
    const button = $("#consolidate-btn");
    const day = $("#consolidate-date").value || localDateString(-1);
    button.disabled = true;
    button.textContent = "整理中…";
    try {
      const data = await apiPost("consolidate", { day });
      const result = data.result || {};
      toast(`已整理 ${day}：${result.memories ?? 0} 条记忆`);
      await loadOverview();
    } catch (error) {
      toast(`整理失败：${error.message}`, true);
    } finally {
      button.disabled = false;
      button.textContent = "立即整理";
    }
  });

  $("#user-list").addEventListener(
    "toggle",
    (event) => {
      const detail = event.target;
      if (!(detail instanceof HTMLElement) || !detail.classList.contains("user-card")) return;
      if (!detail.open) return;
      const body = detail.querySelector(".card-body");
      if (body && body.dataset.loaded !== "1") loadUserDetail(detail, 0);
    },
    true,
  );

  document.addEventListener("click", async (event) => {
    const target = event.target.closest("[data-action]");
    if (!target) return;
    const action = target.dataset.action;

    if (action === "open-user") {
      openUser(target.dataset.key || "");
      return;
    }
    if (action === "filter-keyword") {
      setKeywordFilter(target.dataset.kw || "");
      return;
    }
    if (action === "more-user-memories") {
      const detail = target.closest(".user-card");
      if (detail) {
        target.disabled = true;
        await loadUserDetail(detail, Number(target.dataset.offset || 0));
      }
      return;
    }
    if (action === "delete-memory") {
      const ok = await confirmDialog("删除记忆", "删除后无法恢复，确定删除这条记忆吗？");
      if (!ok) return;
      try {
        await apiPost("memory/delete", { id: Number(target.dataset.id) });
        toast("记忆已删除");
        await refreshCurrent();
      } catch (error) {
        toast(`删除失败：${error.message}`, true);
      }
      return;
    }
    if (action === "delete-keyword") {
      const ok = await confirmDialog(
        "删除关键字",
        "只删除该条记忆上的这个关键字，记忆本身会保留。",
        "删除关键字",
      );
      if (!ok) return;
      try {
        await apiPost("keyword/delete", {
          memory_id: Number(target.dataset.id),
          keyword: target.dataset.kw,
        });
        toast("关键字已删除");
        await refreshCurrent();
      } catch (error) {
        toast(`删除失败：${error.message}`, true);
      }
      return;
    }
    if (action === "delete-profile") {
      const ok = await confirmDialog("删除画像", "删除后下一次整理会重新生成画像。", "删除画像");
      if (!ok) return;
      try {
        await apiPost("profile/delete", { user_key: target.dataset.key });
        toast("画像已删除");
        await refreshCurrent();
      } catch (error) {
        toast(`删除失败：${error.message}`, true);
      }
      return;
    }
    if (action === "delete-user") {
      const ok = await confirmDialog(
        "清空用户数据",
        "将删除该用户的全部消息、记忆、画像和关键字，无法恢复。",
        "清空数据",
      );
      if (!ok) return;
      try {
        await apiPost("user/delete", { user_key: target.dataset.key });
        toast("用户数据已清空");
        await refreshCurrent();
      } catch (error) {
        toast(`删除失败：${error.message}`, true);
      }
    }
  });
}

async function refreshCurrent() {
  if (state.tab === "overview") {
    await loadOverview();
  } else if (state.tab === "users") {
    await loadUsers(true);
  } else if (state.tab === "memories") {
    await loadMemories(true);
  }
}

async function init() {
  $("#consolidate-date").value = localDateString(-1);
  setupEvents();
  await initBridge();
  await loadOverview();
}

document.addEventListener("DOMContentLoaded", init);
